const $=s=>document.querySelector(s);
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const LN=NATIVE?Capacitor.Plugins.LocalNotifications:null;
let NP="prompt";
const T={ar:{app:"ذكرني",date:"تذكير مرة واحدة",week:"تذكير متكرر",set:"الإعدادات",search:"بحث في التذكيرات...",empty:"مفيش تذكيرات لسه",add:"+ إضافة تذكير",msg:"نص التذكير",d:"التاريخ",tm:"الوقت",day:"اليوم",save:"حفظ",cancel:"إلغاء",del:"حذف",edit:"تعديل",newr:"تذكير جديد",editr:"تعديل التذكير",conf:"هل أنت متأكد أنك تريد حذف هذا التذكير؟",act:"نشط",pau:"متوقف",pause:"إيقاف مؤقت",resume:"استئناف",pin:"تثبيت",snooze:"تأجيل",m10:"10 دقائق",m30:"30 دقيقة",h1:"ساعة",tom:"غداً",cust:"وقت مخصص",ok:"تم",rem:"افتكر: ",title:"ذكرني 🔔",ap:"المظهر",light:"فاتح",dark:"داكن",sys:"النظام",col:"لون التطبيق",lang:"اللغة",nt:"الإشعارات",allow:"السماح بالإشعارات",granted:"الإشعارات مفعّلة ✅",denied:"الإشعارات مرفوضة. التذكيرات تحتاج إذن الإشعارات، فعّلها من إعدادات المتصفح للموقع.",def:"لم يتم طلب الإذن بعد.",nosup:"المتصفح لا يدعم الإشعارات.",bad:"اكتب نص التذكير واختر وقتاً صحيحاً في المستقبل",warn:"ملاحظة: التنبيهات تعمل أثناء فتح هذه الصفحة."},
en:{app:"Zakkerni",date:"One-time Reminder",week:"Repeating Reminder",set:"Settings",search:"Search reminders...",empty:"No reminders yet",add:"+ Add Reminder",msg:"Reminder text",d:"Date",tm:"Time",day:"Day",save:"Save",cancel:"Cancel",del:"Delete",edit:"Edit",newr:"New reminder",editr:"Edit reminder",conf:"Are you sure you want to delete this reminder?",act:"Active",pau:"Paused",pause:"Pause",resume:"Resume",pin:"Pin",snooze:"Snooze",m10:"10 minutes",m30:"30 minutes",h1:"1 hour",tom:"Tomorrow",cust:"Custom time",ok:"OK",rem:"Remember: ",title:"Zakkerni 🔔",ap:"Appearance",light:"Light",dark:"Dark",sys:"System",col:"App color",lang:"Language",nt:"Notifications",allow:"Allow notifications",granted:"Notifications enabled ✅",denied:"Notifications are blocked. Reminders need notification permission; enable it in your browser's site settings.",def:"Permission not requested yet.",nosup:"This browser doesn't support notifications.",bad:"Enter a reminder text and a valid future time",warn:"Note: alerts work while this page is open."}};
Object.assign(T.ar,{denied2:"الإشعارات مرفوضة. فعّلها من: إعدادات الموبايل ← التطبيقات ← ذكرني ← الإشعارات."});
Object.assign(T.en,{denied2:"Notifications are blocked. Enable them in: phone Settings → Apps → Zakkerni → Notifications."});
Object.assign(T.ar,{app:"فكرني",title:"فكرني 🔔",n_date:"مرة واحدة",n_week:"متكرر",n_table:"المذاكرة",n_set:"الإعدادات",tb:"جدول المذاكرة",d_date:"يظهر مرة واحدة في تاريخ ووقت محدد",d_week:"يتكرر كل أسبوع في يوم ووقت محدد",d_table:"جداول حصصك، وتنبيه قبل كل حصة بنص ساعة",d_set:"المظهر واللغة والإشعارات",notb:"مفيش جداول لسه",mk:"+ إنشاء جدول",nos:"لا توجد حصص",tname:"اسم الجدول",newt:"جدول جديد",addc:"حصة جديدة",editc:"تعديل الحصة",subj:"المادة",from:"من",to:"إلى",confT:"هل أنت متأكد أنك تريد حذف هذا الجدول؟",confS:"هل أنت متأكد أنك تريد حذف هذه الحصة؟",bads:"اكتب اسم المادة وتأكد إن وقت النهاية بعد البداية"});
Object.assign(T.en,{app:"Fakkerni",title:"Fakkerni 🔔",n_date:"One-time",n_week:"Repeating",n_table:"Study",n_set:"Settings",tb:"Study Timetable",d_date:"Shows once at a set date and time",d_week:"Repeats every week on a set day and time",d_table:"Class schedules with an alert 30 min before",d_set:"Look, language & notifications",notb:"No timetables yet",mk:"+ Create timetable",nos:"No classes",tname:"Timetable name",newt:"New timetable",addc:"New class",editc:"Edit class",subj:"Subject",from:"From",to:"To",confT:"Are you sure you want to delete this timetable?",confS:"Are you sure you want to delete this class?",bads:"Enter a subject and make sure the end time is after the start"});
const TABS=["date","week","table","set"];let ANIM=true,liqInit=false,selT=null;
const IC={date:'<path class="f" d="M5 6.3c3.7-.4 10.3-.4 14 0 .5 3.5.5 9.5 0 13.1-3.8.5-10.2.5-14 0-.5-3.6-.5-9.6 0-13.1z"/><path d="M5.2 10.5c4.3.3 9.3.3 13.6 0M8.6 3.7v3.9M15.4 3.7v3.9M8.8 14.2h.1M12 14.2h.1M15.2 14.2h.1M8.8 17h.1M12 17h.1"/>',week:'<path d="M5 12.2a7 7 0 0 1 12.1-4.8M17.8 3.8v3.6h-3.6M19 11.8a7 7 0 0 1-12.1 4.8M6.2 20.2v-3.6h3.6"/><circle class="f" cx="12" cy="12" r="1.6"/>',table:'<path class="f" d="M4.7 7c0-1.3.7-2 2-2h10.6c1.3 0 2 .7 2 2v10c0 1.3-.7 2-2 2H6.7c-1.3 0-2-.7-2-2z"/><path d="M4.8 10.3h14.4M4.8 14.7h14.4M10.2 10.3v8.7"/>',set:'<path d="M4.5 7h15M4.5 12h15M4.5 17h15"/><circle class="f" cx="9" cy="7" r="2.4"/><circle class="f" cx="15.5" cy="12" r="2.4"/><circle class="f" cx="8" cy="17" r="2.4"/>',edit:'<path class="f" d="M4.6 19.6l.9-3.9L16.3 4.9a1.9 1.9 0 0 1 2.7 0l.1.1a1.9 1.9 0 0 1 0 2.7L8.4 18.7z"/><path d="M14.6 6.6l2.8 2.8"/>',trash:'<path class="f" d="M6.6 7.6l.9 11.1c.1.8.6 1.2 1.4 1.2h6.2c.8 0 1.3-.4 1.4-1.2l.9-11.1z"/><path d="M4.8 7.4h14.4M9.4 7.4l.5-2.7h4.2l.5 2.7M10.2 11v5.4M13.8 11v5.4"/>',pin:'<path class="f" d="M9 4.6h6l-.8 4.6 2.8 2.9c.3.3.1.9-.4.9H7.4c-.5 0-.7-.6-.4-.9l2.8-2.9z"/><path d="M12 13v6.6"/>',pause:'<rect class="f" x="6" y="5" width="4" height="14" rx="1.6"/><rect class="f" x="14" y="5" width="4" height="14" rx="1.6"/>',play:'<path class="f" d="M8 5.4c0-.8.9-1.2 1.5-.8l9 6.1c.6.4.6 1.2 0 1.6l-9 6.1c-.6.4-1.5 0-1.5-.8z"/>',bell:'<path class="f" d="M12 3.4c-3.2 0-5.2 2.4-5.2 5.6v3.2c0 1.2-.5 2.2-1.4 3.2-.4.5-.1 1.2.5 1.2h12.2c.6 0 .9-.7.5-1.2-.9-1-1.4-2-1.4-3.2V9c0-3.2-2-5.6-5.2-5.6z"/><path d="M9.8 19.2c.3 1.2 1.1 1.8 2.2 1.8s1.9-.6 2.2-1.8"/>',plus:'<path d="M12 5.4v13.2M5.4 12h13.2"/>'};
const ic=n=>`<svg class="hi" viewBox="0 0 24 24" aria-hidden="true"><g class="sh" transform="translate(1.1 1.1)">${IC[n]}</g><g class="ol">${IC[n]}</g></svg>`;
const DAYS=()=>S.lang==="ar"?[6,0,1,2,3,4,5]:[0,1,2,3,4,5,6];
const curT=()=>TB.find(x=>x.id===selT)||TB[0];
const fm=s=>{const[h,m]=s.split(":");return ft(new Date(2024,0,1,+h,+m))};
function moveLiq(){document.documentElement.style.setProperty("--navh",$("#nv").offsetHeight+"px");const b=document.querySelector("#tabs .on");if(!b)return;const x=b.offsetLeft+b.offsetWidth/2-22,L=document.querySelectorAll("#liq i");
if(!liqInit){liqInit=true;L.forEach(i=>i.style.transition="none")}
L.forEach(i=>i.style.transform=`translateX(${x}px)`);
if(L[0].style.transition==="none"){void L[0].offsetWidth;L.forEach(i=>i.style.transition="")}}
window.addEventListener("resize",moveLiq);
const mh=(ti,sa,ca='data-a="close"')=>`<div class="mh"><button class="btn sec" ${ca}>${t("cancel")}</button><h3>${ti}</h3><button class="btn" ${sa}>${t("save")}</button></div>`;
function confirmM(m,a,id){modal(`<h3>${t("del")}</h3><p>${t(m)}</p><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn red" data-a="${a}" data-id="${id}">${t("del")}</button></div>`)}
function tForm(id){const x=TB.find(y=>y.id===id);modal(`${mh(t("newt"),`data-a="savet" data-id="${id||""}"`)}<label>${t("tname")}</label><input id="t_n" maxlength="40" value="${x?esc(x.name):""}">`)}
Object.assign(T.ar,{am:"ص",pm:"م",c_d:"يوم",c_m:"شهر",c_y:"سنة"});Object.assign(T.en,{am:"AM",pm:"PM",c_d:"Day",c_m:"Month",c_y:"Year"});
const nm2=n=>n.toLocaleString(loc(),{minimumIntegerDigits:2,useGrouping:false}),nm1=n=>n.toLocaleString(loc(),{useGrouping:false});
const rng=(a,b,f)=>Array.from({length:b-a+1},(_,i)=>f(a+i));
const wheel=(id,items,sel,fx)=>`<div class="wh" id="${id}" data-n="${items.length}" data-sel="${sel}" style="flex:${fx||1}">${items.map((x,i)=>`<div class="wi${i===sel?" sel":""}">${x}</div>`).join("")}</div>`;
const wv=id=>{const e=$("#"+id);return Math.max(0,Math.min(+e.dataset.n-1,Math.round(e.scrollTop/40)))};
const timeW=(p,h,m)=>`<div class="whs">${wheel(p+"h",rng(1,12,nm1),(h%12||12)-1)}<span class="sep">:</span>${wheel(p+"m",rng(0,59,nm2),m)}${wheel(p+"p",[t("am"),t("pm")],h>=12?1:0)}</div>`;
const tv=p=>{const h=(wv(p+"h")+1)%12+(wv(p+"p")?12:0);return pad(h)+":"+pad(wv(p+"m"))};
const dateW=(p,d)=>{const y0=new Date().getFullYear();return `<div class="caps"><span>${t("c_d")}</span><span>${t("c_m")}</span><span style="flex:1.3">${t("c_y")}</span></div><div class="whs">${wheel(p+"d",rng(1,31,nm1),d.getDate()-1)}${wheel(p+"m",rng(1,12,nm1),d.getMonth())}${wheel(p+"y",rng(y0,y0+9,nm1),Math.max(0,Math.min(9,d.getFullYear()-y0)),1.3)}</div>`};
const wdate=p=>{const y=new Date().getFullYear()+wv(p+"y"),m=wv(p+"m")+1,d=wv(p+"d")+1;return new Date(y,m-1,d).getMonth()===m-1?[y,m,d]:[0,0,0]};
const dayW=(p,day)=>`<div class="whs">${wheel(p,DAYS().map(dayName),Math.max(0,DAYS().indexOf(day)))}</div>`;
const wd=p=>DAYS()[wv(p)];
function initWheels(){document.querySelectorAll(".wh").forEach(e=>{e.scrollTop=(+e.dataset.sel)*40})}
document.addEventListener("scroll",e=>{const el=e.target;if(!el.classList||!el.classList.contains("wh"))return;cancelAnimationFrame(el._r);el._r=requestAnimationFrame(()=>{const i=Math.round(el.scrollTop/40);el.querySelectorAll(".wi").forEach((x,k)=>x.classList.toggle("sel",k===i))})},true);
function sForm(id,day){const x=curT().items.find(y=>y.id===id),d=x?x.day:day,[a1,a2]=(x?x.s:"16:00").split(":").map(Number),[b1,b2]=(x?x.e:"17:00").split(":").map(Number);modal(`${mh(t(x?"editc":"addc"),`data-a="saves" data-id="${id||""}"`)}<label>${t("subj")}</label><input id="s_s" maxlength="40" value="${x?esc(x.sub):""}"><label>${t("day")}</label>${dayW("s_d",d)}<label>${t("from")}</label>${timeW("s_a",a1,a2)}<label>${t("to")}</label>${timeW("s_b",b1,b2)}`)}
Object.assign(T.ar,{fnt:"الخط",custc:"لون مخصص",gd:"شرح التطبيق",pre:"قوم جهّز يلا، وراك درس "});Object.assign(T.en,{fnt:"Font",custc:"Custom color",gd:"App guide",pre:"Get ready, you have class: "});
const FONTS=[{id:"cairo",n:"Cairo",css:"'Cairo Variable'"},{id:"tajawal",n:"Tajawal",css:"'Tajawal'"},{id:"amiri",n:"Amiri",css:"'Amiri'"},{id:"reem",n:"Reem Kufi",css:"'Reem Kufi Variable'"},{id:"baloo",n:"Baloo",css:"'Baloo Bhaijaan 2 Variable'"}];
const COLORS=["#6750A4","#512DA8","#3949AB","#1565C0","#0277BD","#00838F","#0B7A75","#2E7D32","#558B2F","#EF6C00","#E65100","#C62828","#D81B60","#AD1457","#6D4C41","#455A64"];
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
let S=ld("zk_s",{theme:"system",color:COLORS[0],lang:"ar"}),R=ld("zk_r",[]),tab="date",Q="",AL=[];let TB=ld("zk_t",[]);
const t=k=>T[S.lang][k];
const sv=()=>{try{localStorage.setItem("zk_s",JSON.stringify(S));localStorage.setItem("zk_r",JSON.stringify(R));localStorage.setItem("zk_t",JSON.stringify(TB))}catch(e){}queueSync()};
const loc=()=>S.lang==="ar"?"ar-EG":"en-US";
const fd=ts=>new Date(ts).toLocaleDateString(loc(),{dateStyle:"long"});
const ft=ts=>new Date(ts).toLocaleTimeString(loc(),{timeStyle:"short"});
const dayName=i=>new Date(2024,0,7+i).toLocaleDateString(loc(),{weekday:"long"});
const esc=s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pad=n=>String(n).padStart(2,"0");
function nextOcc(r,from){const d=new Date(from);d.setHours(r.h,r.m,0,0);d.setDate(d.getDate()+(r.day-d.getDay()+7)%7);if(d.getTime()<=from)d.setDate(d.getDate()+7);return d.getTime()}
function applyStyle(){const h=document.documentElement;h.dataset.theme=S.theme;h.style.setProperty("--p",S.color);h.style.setProperty("--ff",(FONTS.find(f=>f.id===S.font)||FONTS[0]).css);h.lang=S.lang;h.dir=S.lang==="ar"?"rtl":"ltr";document.title=t("app")}
function render(){applyStyle();
if(ANIM){$("#hd").innerHTML=`<span class="bell">${ic("bell")}</span><span class="hn">${t("app")}</span>`;$("#fab").innerHTML=ic("plus");$("#fab").setAttribute("aria-label",t("add"));
$("#tabs").innerHTML=TABS.map(k=>`<button class="${tab===k?"on":""}" data-tab="${k}"><span class="ti">${ic(k)}</span>${t("n_"+k)}</button>`).join("");
$("#bn").className="bn t-"+tab;$("#bn").innerHTML=`<span class="bi">${ic(tab)}</span><div><b>${t(tab==="table"?"tb":tab)}</b><small>${t("d_"+tab)}</small></div>`}
$("#sw").style.display=(tab==="date"||tab==="week")?"block":"none";$("#fab").style.display=(tab==="date"||tab==="week")?"grid":"none";$("#q").placeholder=t("search");
tab==="set"?renderSet():tab==="table"?renderTable():renderList();moveLiq();ANIM=false}
function renderList(){let L=R.filter(r=>r.type===tab&&r.text.toLowerCase().includes(Q.toLowerCase()));
L.sort((a,b)=>(b.pin-a.pin)||((tab==="date"?a.at:a.next)-(tab==="date"?b.at:b.next)));
if(!L.length&&!Q){$("#mn").innerHTML=`<div class="empty"><div class="eb">${ic("bell")}</div><p>${t("empty")}</p><button class="btn" data-a="new">${t("add")}</button></div>`;return}
$("#mn").innerHTML=L.map((r,i)=>{const w=r.type==="week";return `<div class="card k-${r.type} ${w&&!r.active?"off":""} ${ANIM?"in":""}" style="--i:${i}"><div class="row"><div class="tt">${r.pin?`<span class="pn">${ic("pin")}</span>`:""}${esc(r.text)}</div>${w?`<span class="chip ${r.active?"":"paused"}">${r.active?t("act"):t("pau")}</span>`:""}</div>
<div class="meta">${w?dayName(r.day)+" • "+ft(new Date(2024,0,1,r.h,r.m)):fd(r.at)+" • "+ft(r.at)}</div>
<div class="row" style="margin-top:6px"><button class="ic" title="${t("edit")}" data-a="edit" data-id="${r.id}">${ic("edit")}</button><button class="ic" title="${t("del")}" data-a="del" data-id="${r.id}">${ic("trash")}</button><button class="ic ${r.pin?"on":""}" title="${t("pin")}" data-a="pin" data-id="${r.id}">${ic("pin")}</button>${w?`<button class="ic" title="${r.active?t("pause"):t("resume")}" data-a="tog" data-id="${r.id}">${ic(r.active?"pause":"play")}</button>`:""}</div></div>`}).join("")}
function renderTable(){
if(!TB.length){$("#mn").innerHTML=`<div class="empty"><div class="eb">${ic("table")}</div><p>${t("notb")}</p><button class="btn" data-a="newt">${t("mk")}</button></div>`;return}
const T0=curT();selT=T0.id;
$("#mn").innerHTML=`<div class="chips">${TB.map(x=>`<button class="chip2 ${x.id===T0.id?"on":""}" data-a="selt" data-id="${x.id}">${esc(x.name)}</button>`).join("")}<button class="chip2" data-a="newt">+</button></div>
<div class="row" style="margin:4px 0 8px"><div class="tt">${esc(T0.name)}</div><button class="ic" data-a="rnt">${ic("edit")}</button><button class="ic" data-a="delt">${ic("trash")}</button></div>`+
DAYS().map((d,i)=>{const L=T0.items.filter(x=>x.day===d).sort((a,b)=>a.s.localeCompare(b.s));
return `<div class="card ${ANIM?"in":""}" style="--i:${i}"><div class="row"><div class="tt">${dayName(d)}</div><button class="ic" data-a="adds" data-d="${d}">${ic("plus")}</button></div>${L.length?L.map(x=>`<div class="row ses"><span class="tm">${fm(x.s)} – ${fm(x.e)}</span><span class="tt">${esc(x.sub)}</span><button class="ic" data-a="eds" data-id="${x.id}">${ic("edit")}</button><button class="ic" data-a="dels" data-id="${x.id}">${ic("trash")}</button></div>`).join(""):`<div class="meta">${t("nos")}</div>`}</div>`}).join("")}
function renderSet(){const canAsk=NATIVE?(NP!=="granted"&&NP!=="denied"):("Notification"in window&&Notification.permission==="default");const nt=NATIVE?(NP==="granted"?t("granted"):NP==="denied"?t("denied2"):t("def")):!("Notification"in window)?t("nosup"):Notification.permission==="granted"?t("granted"):Notification.permission==="denied"?t("denied"):t("def");
$("#mn").innerHTML=`<h4>${t("ap")}</h4><div class="seg">${[["light","light"],["dark","dark"],["system","sys"]].map(([v,k])=>`<button class="${S.theme===v?"on":""}" data-th="${v}">${t(k)}</button>`).join("")}</div>
<h4>${t("col")}</h4><div class="sw">${COLORS.map(c=>`<i data-co="${c}" class="${S.color===c?"on":""}" style="background:${c}"></i>`).join("")}<label class="cus" title="${t("custc")}"><input type="color" id="cc" value="${S.color}"></label></div><h4>${t("fnt")}</h4><div class="fonts">${FONTS.map(f=>`<button class="fb ${S.font===f.id?"on":""}" data-fn="${f.id}" style="font-family:${f.css}"><b>فكرني</b><small>${f.n}</small></button>`).join("")}</div>
<h4>${t("lang")}</h4><div class="seg"><button class="${S.lang==="ar"?"on":""}" data-lg="ar">العربية</button><button class="${S.lang==="en"?"on":""}" data-lg="en">English</button></div>
<h4>${t("nt")}</h4><p>${nt}</p>${canAsk?`<br><button class="btn" data-a="perm">${t("allow")}</button>`:""}${NATIVE?"":`<p class="note">${t("warn")}</p>`}<h4>${t("gd")}</h4><img class="guide" src="guide.webp" alt="${t("gd")}">`}
function modal(h){$("#md").innerHTML=h;$("#ov").classList.add("show");initWheels()}
function closeM(){$("#ov").classList.remove("show")}
function form(id){const r=R.find(x=>x.id===id),w=(r?r.type:tab)==="week";const d=r&&!w?new Date(r.at):new Date(Date.now()+3600e3);const h=r&&w?r.h:d.getHours(),mi=r&&w?r.m:d.getMinutes();
modal(`${mh(r?t("editr"):t("newr"),`data-a="save" data-id="${id||""}" data-w="${w?1:0}"`)}<label>${t("msg")}</label><input id="f_t" value="${r?esc(r.text):""}" maxlength="120">
<label>${w?t("day"):t("d")}</label>${w?dayW("f_d",r?r.day:4):dateW("f_d",d)}
<label>${t("tm")}</label>${timeW("f_m",h,mi)}
`)}
function saveForm(id,w){const text=$("#f_t").value.trim(),tm=tv("f_m");if(!text||!tm)return alert(t("bad"));const[h,m]=tm.split(":").map(Number);let r=R.find(x=>x.id===id);
if(!r){r={id:Date.now()+Math.random(),nid:nextNid(),type:w?"week":"date",pin:false,active:true,created:Date.now()};R.push(r)}
r.text=text;r.h=h;r.m=m;r.snooze=null;
if(w){r.day=wd("f_d");r.next=nextOcc(r,Date.now())}else{const[y,mo,da]=wdate("f_d");r.at=new Date(y,mo-1,da,h,m).getTime();if(!y||r.at<=Date.now()){if(!id)R.pop();return alert(t("bad"))}}
sv();closeM();render()}
function fire(r){if(NATIVE)return;AL.push({...r});try{if("Notification"in window&&Notification.permission==="granted")new Notification(t("title"),{body:t("rem")+r.text})}catch(e){}try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){}if(!$("#ov").classList.contains("show"))showAlert()}
function showAlert(){const a=AL[0];if(!a)return closeM();const w=a.type==="week";
modal(`<h3>${t("title")}</h3><p style="font-size:20px;margin:6px 0">${t("rem")}${esc(a.text)}</p><div class="acts"><button class="btn sec" data-a="snz">${t("snooze")}</button><button class="btn sec" data-a="${w?"apause":"adel"}">${w?t("pause"):t("del")}</button><button class="btn" data-a="dis">${t("ok")}</button></div>`)}
function snoozeMenu(){modal(`${mh(t("snooze"),'data-sn="c"','data-a="alert"')}<div class="seg" style="flex-direction:column">${[["m10",10],["m30",30],["h1",60],["tom",-1]].map(([k,v])=>`<button data-sn="${v}">${t(k)}</button>`).join("")}</div><label>${t("cust")}</label>${dateW("sn_c",new Date(Date.now()+3600e3))}${timeW("sn_t",new Date(Date.now()+3600e3).getHours(),new Date(Date.now()+3600e3).getMinutes())}`)}
function doSnooze(v){const a=AL[0];let ts;if(v==="c"){{const[y,mo,da]=wdate("sn_c"),[hh,mm]=tv("sn_t").split(":").map(Number);ts=y?new Date(y,mo-1,da,hh,mm).getTime():0}if(!ts||ts<=Date.now())return alert(t("bad"))}else if(+v<0){const d=new Date();d.setDate(d.getDate()+1);const hm=a.type==="week"?[a.h,a.m]:[new Date(a.at).getHours(),new Date(a.at).getMinutes()];d.setHours(hm[0],hm[1],0,0);ts=d.getTime()}else ts=Date.now()+v*60000;
if(a.type==="date"){R=R.filter(y=>y.id!==a.id);R.push({...a,at:ts})}else{const r=R.find(x=>x.id===a.id);if(r)r.snooze=ts}
AL.shift();sv();render();showAlert()}
function tick(){const n=Date.now();let ch=false;for(const r of [...R]){if(r.type==="date"){if(r.at<=n){fire(r);R=R.filter(x=>x!==r);ch=true}}else if(r.active){if(r.snooze&&r.snooze<=n){fire(r);r.snooze=null;ch=true}if(r.next<=n){fire(r);r.next=nextOcc(r,n);ch=true}}}if(ch){sv();if(tab!=="set")render()}}
document.addEventListener("click",e=>{const el=e.target.closest("[data-tab],[data-a],[data-th],[data-co],[data-lg],[data-sn],[data-fn]");if(!el)return;const D=el.dataset,id=D.id?+D.id:null,r=R.find(x=>x.id===id);
if(D.tab)go(D.tab)
else if(D.fn){S.font=D.fn;sv();render()}else if(D.th){S.theme=D.th;sv();render()}else if(D.co){S.color=D.co;sv();render()}else if(D.lg){S.lang=D.lg;ANIM=true;sv();render()}
else if(D.sn)doSnooze(D.sn);
else switch(D.a){case"new":form(null);break;case"edit":form(id);break;case"close":closeM();break;case"save":saveForm(id,D.w==="1");break;
case"del":modal(`<h3>${t("del")}</h3><p>${t("conf")}</p><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn red" data-a="cdel" data-id="${id}">${t("del")}</button></div>`);break;
case"cdel":R=R.filter(x=>x.id!==id);sv();closeM();render();break;
case"pin":r.pin=!r.pin;sv();render();break;
case"tog":r.active=!r.active;r.snooze=null;if(r.active)r.next=nextOcc(r,Date.now());sv();render();break;
case"perm":if(NATIVE)LN.requestPermissions().then(p=>{NP=p.display;render()});else Notification.requestPermission().then(render);break;
case"newt":tForm(null);break;case"rnt":tForm(curT().id);break;
case"savet":{const nm=$("#t_n").value.trim();if(!nm)return;if(id){TB.find(y=>y.id===id).name=nm}else{const n={id:Date.now()+Math.random(),name:nm,items:[]};TB.push(n);selT=n.id}sv();closeM();render();break}
case"selt":selT=id;render();break;
case"delt":confirmM("confT","cdelt",curT().id);break;
case"cdelt":TB=TB.filter(y=>y.id!==id);selT=null;sv();closeM();render();break;
case"adds":sForm(null,+D.d);break;case"eds":sForm(id,0);break;
case"saves":{const sub=$("#s_s").value.trim(),s=tv("s_a"),e=tv("s_b");if(!sub||!s||!e||e<=s)return alert(t("bads"));const T0=curT();let x=T0.items.find(y=>y.id===id);if(!x){x={id:Date.now()+Math.random()};T0.items.push(x)}if(!x.nid)x.nid=nextNid();x.sub=sub;x.s=s;x.e=e;x.day=wd("s_d");sv();closeM();render();break}
case"dels":confirmM("confS","cdels",id);break;
case"cdels":{const T0=curT();T0.items=T0.items.filter(y=>y.id!==id);sv();closeM();render();break}
case"snz":snoozeMenu();break;case"alert":showAlert();break;
case"dis":case"adel":AL.shift();showAlert();break;
case"apause":{const x=R.find(y=>y.id===AL[0].id);if(x){x.active=false;x.snooze=null;sv();render()}AL.shift();showAlert();break}}});
$("#q").addEventListener("input",e=>{Q=e.target.value;renderList()});
function slideIn(l){const m=$("#mn");m.style.transition="";m.style.transform="";m.classList.remove("sl","sr");void m.offsetWidth;m.classList.add(l?"sl":"sr")}
function go(k){if(k===tab)return;const o=TABS.indexOf(tab),n=TABS.indexOf(k),l=S.lang==="ar"?n>o:n<o;tab=k;Q="";$("#q").value="";ANIM=true;render();slideIn(l)}
let tx=0,ty=0,tOK=false,drag=false;
const dirOf=dx=>{const j=TABS.indexOf(tab)+((dx>0)===(S.lang==="ar")?1:-1);return j>=0&&j<TABS.length?TABS[j]:null};
document.addEventListener("touchstart",e=>{const c=e.touches[0];tx=c.clientX;ty=c.clientY;drag=false;tOK=e.touches.length===1&&!e.target.closest(".wh,.chips,#ov,nav,input,select,textarea")},{passive:true});
document.addEventListener("touchmove",e=>{if(!tOK)return;const c=e.touches[0],dx=c.clientX-tx,dy=c.clientY-ty;if(!drag&&Math.abs(dx)>12&&Math.abs(dx)>1.4*Math.abs(dy))drag=true;if(drag){const m=$("#mn");m.style.transition="none";m.style.transform=`translateX(${dirOf(dx)?dx:dx*.25}px)`}},{passive:true});
document.addEventListener("touchend",e=>{if(!tOK)return;tOK=false;if(!drag)return;drag=false;const dx=e.changedTouches[0].clientX-tx,m=$("#mn"),k=dirOf(dx);
if(k&&Math.abs(dx)>80){m.style.transition="transform .18s ease-in";m.style.transform=`translateX(${dx>0?"110%":"-110%"})`;setTimeout(()=>go(k),170)}else{m.style.transition="transform .25s cubic-bezier(.2,.9,.3,1.2)";m.style.transform="";setTimeout(()=>{m.style.transition=""},260)}},{passive:true});
document.addEventListener("input",e=>{if(e.target.id==="cc"){S.color=e.target.value;sv();applyStyle()}});
function nextNid(){S.nid=(S.nid||0)+1;return S.nid}
let syncT=null,syncing=Promise.resolve();
function queueSync(){if(!NATIVE)return;clearTimeout(syncT);syncT=setTimeout(()=>{syncing=syncing.then(syncAll).catch(()=>{})},300)}
async function syncAll(){
const pend=await LN.getPending();
if(pend.notifications.length)await LN.cancel({notifications:pend.notifications.map(n=>({id:n.id}))});
await LN.createChannel({id:"zk_reminders",name:t("app"),description:t("title"),importance:5,visibility:1,vibration:true});
await LN.registerActionTypes({types:[{id:"DATE",actions:[{id:"snooze",title:t("snooze")},{id:"delete",title:t("del")}]},{id:"WEEK",actions:[{id:"snooze",title:t("snooze")},{id:"pause",title:t("pause")}]}]});
const now=Date.now(),list=[];
for(const r of R){
const b={title:t("title"),body:t("rem")+r.text,channelId:"zk_reminders",actionTypeId:r.type==="week"?"WEEK":"DATE",extra:r};
if(r.type==="date"){if(r.at>now)list.push({...b,id:r.nid*4,schedule:{at:new Date(r.at),allowWhileIdle:true}})}
else if(r.active){list.push({...b,id:r.nid*4,schedule:{on:{weekday:r.day+1,hour:r.h,minute:r.m},allowWhileIdle:true}});
if(r.snooze&&r.snooze>now)list.push({...b,id:r.nid*4+1,schedule:{at:new Date(r.snooze),allowWhileIdle:true}})}}
for(const T0 of TB)for(const x of T0.items){if(!x.nid)x.nid=nextNid();const[h,m]=x.s.split(":").map(Number);let tot=h*60+m-30,d=x.day;if(tot<0){tot+=1440;d=(d+6)%7}
list.push({title:t("title"),body:t("pre")+x.sub,channelId:"zk_reminders",id:1000000000+x.nid*2,schedule:{on:{weekday:d+1,hour:Math.floor(tot/60),minute:tot%60},allowWhileIdle:true}})}
if(list.length)await LN.schedule({notifications:list})}
function handleAction(ev){
const x=(ev.notification&&ev.notification.extra)||{},a=ev.actionId;if(!x.type)return;
const r=R.find(y=>y.id===x.id);
if(a==="snooze"){const rec=r||(x.type==="date"?{...x}:null);if(!rec)return;AL.unshift({...rec});snoozeMenu()}
else if(a==="delete"){R=R.filter(y=>y.id!==x.id);sv();render()}
else if(a==="pause"&&r){r.active=false;r.snooze=null;sv();render()}}
async function nativeInit(){
try{let p=await LN.checkPermissions();if(p.display==="prompt"||p.display==="prompt-with-rationale")p=await LN.requestPermissions();NP=p.display}catch(e){}
try{const e=await LN.checkExactNotificationSetting();if(e.exact_alarm==="denied")await LN.changeExactNotificationSetting()}catch(e){}
try{await LN.addListener("localNotificationActionPerformed",handleAction)}catch(e){}
queueSync();if(tab==="set")render()}
R.forEach(r=>{if(!r.nid)r.nid=nextNid()});TB.forEach(T0=>T0.items.forEach(x=>{if(!x.nid)x.nid=nextNid()}));sv();
render();tick();setInterval(tick,10000);document.addEventListener("visibilitychange",()=>{tick();if(!document.hidden)queueSync()});window.addEventListener("focus",queueSync);if(NATIVE)nativeInit();
