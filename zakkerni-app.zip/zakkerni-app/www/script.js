const $=s=>document.querySelector(s);
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const LN=NATIVE?Capacitor.Plugins.LocalNotifications:null;
let NP="prompt";
const T={ar:{app:"ذكرني",date:"تذكير بتاريخ",week:"تذكير أسبوعي",set:"الإعدادات",search:"بحث في التذكيرات...",empty:"مفيش تذكيرات لسه",add:"+ إضافة تذكير",msg:"نص التذكير",d:"التاريخ",tm:"الوقت",day:"اليوم",save:"حفظ",cancel:"إلغاء",del:"حذف",edit:"تعديل",newr:"تذكير جديد",editr:"تعديل التذكير",conf:"هل أنت متأكد أنك تريد حذف هذا التذكير؟",act:"نشط",pau:"متوقف",pause:"إيقاف مؤقت",resume:"استئناف",pin:"تثبيت",snooze:"تأجيل",m10:"10 دقائق",m30:"30 دقيقة",h1:"ساعة",tom:"غداً",cust:"وقت مخصص",ok:"تم",rem:"افتكر: ",title:"ذكرني 🔔",ap:"المظهر",light:"فاتح",dark:"داكن",sys:"النظام",col:"لون التطبيق",lang:"اللغة",nt:"الإشعارات",allow:"السماح بالإشعارات",granted:"الإشعارات مفعّلة ✅",denied:"الإشعارات مرفوضة. التذكيرات تحتاج إذن الإشعارات، فعّلها من إعدادات المتصفح للموقع.",def:"لم يتم طلب الإذن بعد.",nosup:"المتصفح لا يدعم الإشعارات.",bad:"اكتب نص التذكير واختر وقتاً صحيحاً في المستقبل",warn:"ملاحظة: التنبيهات تعمل أثناء فتح هذه الصفحة."},
en:{app:"Zakkerni",date:"Date Reminder",week:"Weekly Reminder",set:"Settings",search:"Search reminders...",empty:"No reminders yet",add:"+ Add Reminder",msg:"Reminder text",d:"Date",tm:"Time",day:"Day",save:"Save",cancel:"Cancel",del:"Delete",edit:"Edit",newr:"New reminder",editr:"Edit reminder",conf:"Are you sure you want to delete this reminder?",act:"Active",pau:"Paused",pause:"Pause",resume:"Resume",pin:"Pin",snooze:"Snooze",m10:"10 minutes",m30:"30 minutes",h1:"1 hour",tom:"Tomorrow",cust:"Custom time",ok:"OK",rem:"Remember: ",title:"Zakkerni 🔔",ap:"Appearance",light:"Light",dark:"Dark",sys:"System",col:"App color",lang:"Language",nt:"Notifications",allow:"Allow notifications",granted:"Notifications enabled ✅",denied:"Notifications are blocked. Reminders need notification permission; enable it in your browser's site settings.",def:"Permission not requested yet.",nosup:"This browser doesn't support notifications.",bad:"Enter a reminder text and a valid future time",warn:"Note: alerts work while this page is open."}};
Object.assign(T.ar,{denied2:"الإشعارات مرفوضة. فعّلها من: إعدادات الموبايل ← التطبيقات ← ذكرني ← الإشعارات."});
Object.assign(T.en,{denied2:"Notifications are blocked. Enable them in: phone Settings → Apps → Zakkerni → Notifications."});
Object.assign(T.ar,{app:"فكرني",title:"فكرني 🔔",n_date:"بتاريخ",n_week:"أسبوعي",n_table:"المذاكرة",n_set:"الإعدادات",tb:"جدول المذاكرة",d_date:"تذكير لمرة واحدة في تاريخ محدد",d_week:"تذكير يتكرر كل أسبوع",d_table:"جداول حصصك للمذاكرة",d_set:"المظهر واللغة والإشعارات",notb:"مفيش جداول لسه",mk:"+ إنشاء جدول",nos:"لا توجد حصص",tname:"اسم الجدول",newt:"جدول جديد",addc:"حصة جديدة",editc:"تعديل الحصة",subj:"المادة",from:"من",to:"إلى",confT:"هل أنت متأكد أنك تريد حذف هذا الجدول؟",confS:"هل أنت متأكد أنك تريد حذف هذه الحصة؟",bads:"اكتب اسم المادة وتأكد إن وقت النهاية بعد البداية"});
Object.assign(T.en,{app:"Fakkerni",title:"Fakkerni 🔔",n_date:"Date",n_week:"Weekly",n_table:"Study",n_set:"Settings",tb:"Study Timetable",d_date:"One-time reminder on a date",d_week:"Repeats every week",d_table:"Your study class schedules",d_set:"Look, language & notifications",notb:"No timetables yet",mk:"+ Create timetable",nos:"No classes",tname:"Timetable name",newt:"New timetable",addc:"New class",editc:"Edit class",subj:"Subject",from:"From",to:"To",confT:"Are you sure you want to delete this timetable?",confS:"Are you sure you want to delete this class?",bads:"Enter a subject and make sure the end time is after the start"});
const TABS=["date","week","table","set"];let ANIM=true,liqInit=false,selT=null;
const IC={date:'<path class="f" d="M4.5 6.5h15v13h-15z"/><path d="M4.5 10.5h15M8.5 4v4M15.5 4v4M8.5 14h.1M12 14h.1M15.5 14h.1"/>',week:'<path d="M4.5 12a7.5 7.5 0 0 1 13-5l2 2M19.5 4.5V9H15M19.5 12a7.5 7.5 0 0 1-13 5l-2-2M4.5 19.5V15H9"/>',table:'<path class="f" d="M4 5h16v14H4z"/><path d="M4 10h16M4 14.5h16M10 5v14"/>',set:'<path d="M4 7h16M4 12h16M4 17h16"/><circle class="f" cx="9" cy="7" r="2.3"/><circle class="f" cx="15" cy="12" r="2.3"/><circle class="f" cx="8" cy="17" r="2.3"/>',edit:'<path class="f" d="M4 20l1-4L16 5a2 2 0 0 1 3 3L8 19z"/><path d="M14 7l3 3"/>',trash:'<path class="f" d="M7 8l1 12h8l1-12z"/><path d="M5 7.5h14M9.5 7.5V4.5h5v3"/>',pin:'<path class="f" d="M9 4h6l-1 5 3 3v1.5H7V12l3-3z"/><path d="M12 13.5V20"/>',pause:'<rect class="f" x="6" y="5" width="4" height="14" rx="1.5"/><rect class="f" x="14" y="5" width="4" height="14" rx="1.5"/>',play:'<path class="f" d="M8 5l11 7-11 7z"/>',bell:'<path class="f" d="M6 17v-6a6 6 0 0 1 12 0v6l1.5 2h-15z"/><path d="M10 21.5h4"/>',plus:'<path d="M12 5v14M5 12h14"/>'};
const ic=n=>`<svg class="hi" viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;
const DAYS=()=>S.lang==="ar"?[6,0,1,2,3,4,5]:[0,1,2,3,4,5,6];
const curT=()=>TB.find(x=>x.id===selT)||TB[0];
const fm=s=>{const[h,m]=s.split(":");return ft(new Date(2024,0,1,+h,+m))};
function moveLiq(){const b=document.querySelector("#tabs .on");if(!b)return;const x=b.offsetLeft+b.offsetWidth/2-22,L=document.querySelectorAll("#liq i");
if(!liqInit){liqInit=true;L.forEach(i=>i.style.transition="none")}
L.forEach(i=>i.style.transform=`translateX(${x}px)`);
if(L[0].style.transition==="none"){void L[0].offsetWidth;L.forEach(i=>i.style.transition="")}}
window.addEventListener("resize",moveLiq);
function confirmM(m,a,id){modal(`<h3>${t("del")}</h3><p>${t(m)}</p><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn red" data-a="${a}" data-id="${id}">${t("del")}</button></div>`)}
function tForm(id){const x=TB.find(y=>y.id===id);modal(`<h3>${t("newt")}</h3><label>${t("tname")}</label><input id="t_n" maxlength="40" value="${x?esc(x.name):""}"><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn" data-a="savet" data-id="${id||""}">${t("save")}</button></div>`)}
function sForm(id,day){const x=curT().items.find(y=>y.id===id),d=x?x.day:day;modal(`<h3>${t(x?"editc":"addc")}</h3><label>${t("subj")}</label><input id="s_s" maxlength="40" value="${x?esc(x.sub):""}"><label>${t("day")}</label><select id="s_d">${DAYS().map(i=>`<option value="${i}" ${i===d?"selected":""}>${dayName(i)}</option>`).join("")}</select><label>${t("from")}</label><input type="time" id="s_a" value="${x?x.s:"16:00"}"><label>${t("to")}</label><input type="time" id="s_b" value="${x?x.e:"17:00"}"><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn" data-a="saves" data-id="${id||""}">${t("save")}</button></div>`)}
const COLORS=["#6750A4","#0B7A75","#C2185B","#E65100","#1565C0","#2E7D32"];
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
let S=ld("zk_s",{theme:"system",color:COLORS[0],lang:"ar"}),R=ld("zk_r",[]),tab="date",Q="",AL=[];let TB=ld("zk_t",[]);
const t=k=>T[S.lang][k];
const sv=()=>{try{localStorage.setItem("zk_s",JSON.stringify(S));localStorage.setItem("zk_r",JSON.stringify(R));localStorage.setItem("zk_t",JSON.stringify(TB))}catch(e){}queueSync()};
const loc=()=>S.lang==="ar"?"ar-EG":"en-US";
const fd=ts=>new Date(ts).toLocaleDateString(loc(),{dateStyle:"long"});
const ft=ts=>new Date(ts).toLocaleTimeString(loc(),{timeStyle:"short"});
const dayName=i=>new Date(2024,0,7+i).toLocaleDateString(loc(),{weekday:"long"});
const esc=s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const pad=n=>String(n).padStart(2,"0");
function nextOcc(r,from){const d=new Date(from);d.setHours(r.h,r.m,0,0);d.setDate(d.getDate()+(r.day-d.getDay()+7)%7);if(d.getTime()<=from)d.setDate(d.getDate()+7);return d.getTime()}
function applyStyle(){const h=document.documentElement;h.dataset.theme=S.theme;h.style.setProperty("--p",S.color);h.lang=S.lang;h.dir=S.lang==="ar"?"rtl":"ltr";document.title=t("app")}
function render(){applyStyle();
if(ANIM){$("#hd").innerHTML=`<span class="bell">${ic("bell")}</span>${t("app")}`;
$("#tabs").innerHTML=TABS.map(k=>`<button class="${tab===k?"on":""}" data-tab="${k}"><span class="ti">${ic(k)}</span>${t("n_"+k)}</button>`).join("");
$("#bn").className="bn t-"+tab;$("#bn").innerHTML=`<span class="bi">${ic(tab)}</span><div><b>${t(tab==="table"?"tb":tab)}</b><small>${t("d_"+tab)}</small></div>`}
$("#sw").style.display=(tab==="date"||tab==="week")?"block":"none";$("#q").placeholder=t("search");
tab==="set"?renderSet():tab==="table"?renderTable():renderList();moveLiq();ANIM=false}
function renderList(){let L=R.filter(r=>r.type===tab&&r.text.toLowerCase().includes(Q.toLowerCase()));
L.sort((a,b)=>(b.pin-a.pin)||((tab==="date"?a.at:a.next)-(tab==="date"?b.at:b.next)));
if(!L.length&&!Q){$("#mn").innerHTML=`<div class="empty"><div class="eb">${ic("bell")}</div><p>${t("empty")}</p><button class="btn" data-a="new">${t("add")}</button></div>`;return}
$("#mn").innerHTML=L.map((r,i)=>{const w=r.type==="week";return `<div class="card k-${r.type} ${w&&!r.active?"off":""} ${ANIM?"in":""}" style="--i:${i}"><div class="row"><div class="tt">${r.pin?`<span class="pn">${ic("pin")}</span>`:""}${esc(r.text)}</div>${w?`<span class="chip ${r.active?"":"paused"}">${r.active?t("act"):t("pau")}</span>`:""}</div>
<div class="meta">${w?dayName(r.day)+" • "+ft(new Date(2024,0,1,r.h,r.m)):fd(r.at)+" • "+ft(r.at)}</div>
<div class="row" style="margin-top:6px"><button class="ic" title="${t("edit")}" data-a="edit" data-id="${r.id}">${ic("edit")}</button><button class="ic" title="${t("del")}" data-a="del" data-id="${r.id}">${ic("trash")}</button><button class="ic ${r.pin?"on":""}" title="${t("pin")}" data-a="pin" data-id="${r.id}">${ic("pin")}</button>${w?`<button class="ic" title="${r.active?t("pause"):t("resume")}" data-a="tog" data-id="${r.id}">${ic(r.active?"pause":"play")}</button>`:""}</div></div>`}).join("")+`<button class="fab" data-a="new" aria-label="${t("add")}">${ic("plus")}</button>`}
function renderTable(){
if(!TB.length){$("#mn").innerHTML=`<div class="empty"><div class="eb">${ic("table")}</div><p>${t("notb")}</p><button class="btn" data-a="newt">${t("mk")}</button></div>`;return}
const T0=curT();selT=T0.id;
$("#mn").innerHTML=`<div class="chips">${TB.map(x=>`<button class="chip2 ${x.id===T0.id?"on":""}" data-a="selt" data-id="${x.id}">${esc(x.name)}</button>`).join("")}<button class="chip2" data-a="newt">+</button></div>
<div class="row" style="margin:4px 0 8px"><div class="tt">${esc(T0.name)}</div><button class="ic" data-a="rnt">${ic("edit")}</button><button class="ic" data-a="delt">${ic("trash")}</button></div>`+
DAYS().map((d,i)=>{const L=T0.items.filter(x=>x.day===d).sort((a,b)=>a.s.localeCompare(b.s));
return `<div class="card ${ANIM?"in":""}" style="--i:${i}"><div class="row"><div class="tt">${dayName(d)}</div><button class="ic" data-a="adds" data-d="${d}">${ic("plus")}</button></div>${L.length?L.map(x=>`<div class="row ses"><span class="tm">${fm(x.s)} – ${fm(x.e)}</span><span class="tt">${esc(x.sub)}</span><button class="ic" data-a="eds" data-id="${x.id}">${ic("edit")}</button><button class="ic" data-a="dels" data-id="${x.id}">${ic("trash")}</button></div>`).join(""):`<div class="meta">${t("nos")}</div>`}</div>`}).join("")}
function renderSet(){const canAsk=NATIVE?(NP!=="granted"&&NP!=="denied"):("Notification"in window&&Notification.permission==="default");const nt=NATIVE?(NP==="granted"?t("granted"):NP==="denied"?t("denied2"):t("def")):!("Notification"in window)?t("nosup"):Notification.permission==="granted"?t("granted"):Notification.permission==="denied"?t("denied"):t("def");
$("#mn").innerHTML=`<h4>${t("ap")}</h4><div class="seg">${[["light","light"],["dark","dark"],["system","sys"]].map(([v,k])=>`<button class="${S.theme===v?"on":""}" data-th="${v}">${t(k)}</button>`).join("")}</div>
<h4>${t("col")}</h4><div class="sw">${COLORS.map(c=>`<i data-co="${c}" class="${S.color===c?"on":""}" style="background:${c}"></i>`).join("")}</div>
<h4>${t("lang")}</h4><div class="seg"><button class="${S.lang==="ar"?"on":""}" data-lg="ar">العربية</button><button class="${S.lang==="en"?"on":""}" data-lg="en">English</button></div>
<h4>${t("nt")}</h4><p>${nt}</p>${canAsk?`<br><button class="btn" data-a="perm">${t("allow")}</button>`:""}${NATIVE?"":`<p class="note">${t("warn")}</p>`}`}
function modal(h){$("#md").innerHTML=h;$("#ov").classList.add("show")}
function closeM(){$("#ov").classList.remove("show")}
function form(id){const r=R.find(x=>x.id===id),w=(r?r.type:tab)==="week";const d=r&&!w?new Date(r.at):new Date(Date.now()+3600e3);
const dv=`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`,tv=r&&w?`${pad(r.h)}:${pad(r.m)}`:`${pad(d.getHours())}:${pad(d.getMinutes())}`;
modal(`<h3>${r?t("editr"):t("newr")}</h3><label>${t("msg")}</label><input id="f_t" value="${r?esc(r.text):""}" maxlength="120">
${w?`<label>${t("day")}</label><select id="f_d">${[0,1,2,3,4,5,6].map(i=>`<option value="${i}" ${r&&r.day===i||!r&&i===4?"selected":""}>${dayName(i)}</option>`).join("")}</select>`:`<label>${t("d")}</label><input type="date" id="f_d" value="${dv}">`}
<label>${t("tm")}</label><input type="time" id="f_m" value="${tv}">
<div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn" data-a="save" data-id="${id||""}" data-w="${w?1:0}">${t("save")}</button></div>`)}
function saveForm(id,w){const text=$("#f_t").value.trim(),tm=$("#f_m").value;if(!text||!tm)return alert(t("bad"));const[h,m]=tm.split(":").map(Number);let r=R.find(x=>x.id===id);
if(!r){r={id:Date.now()+Math.random(),nid:nextNid(),type:w?"week":"date",pin:false,active:true,created:Date.now()};R.push(r)}
r.text=text;r.h=h;r.m=m;r.snooze=null;
if(w){r.day=+$("#f_d").value;r.next=nextOcc(r,Date.now())}else{const[y,mo,da]=$("#f_d").value.split("-").map(Number);r.at=new Date(y,mo-1,da,h,m).getTime();if(!y||r.at<=Date.now()){if(!id)R.pop();return alert(t("bad"))}}
sv();closeM();render()}
function fire(r){if(NATIVE)return;AL.push({...r});try{if("Notification"in window&&Notification.permission==="granted")new Notification(t("title"),{body:t("rem")+r.text})}catch(e){}try{navigator.vibrate&&navigator.vibrate([200,100,200])}catch(e){}if(!$("#ov").classList.contains("show"))showAlert()}
function showAlert(){const a=AL[0];if(!a)return closeM();const w=a.type==="week";
modal(`<h3>${t("title")}</h3><p style="font-size:20px;margin:6px 0">${t("rem")}${esc(a.text)}</p><div class="acts"><button class="btn sec" data-a="snz">${t("snooze")}</button><button class="btn sec" data-a="${w?"apause":"adel"}">${w?t("pause"):t("del")}</button><button class="btn" data-a="dis">${t("ok")}</button></div>`)}
function snoozeMenu(){modal(`<h3>${t("snooze")}</h3><div class="seg" style="flex-direction:column">${[["m10",10],["m30",30],["h1",60],["tom",-1]].map(([k,v])=>`<button data-sn="${v}">${t(k)}</button>`).join("")}</div><label>${t("cust")}</label><input type="datetime-local" id="sn_c"><div class="acts"><button class="btn sec" data-a="alert">${t("cancel")}</button><button class="btn" data-sn="c">${t("save")}</button></div>`)}
function doSnooze(v){const a=AL[0];let ts;if(v==="c"){ts=new Date($("#sn_c").value).getTime();if(!ts||ts<=Date.now())return alert(t("bad"))}else if(+v<0){const d=new Date();d.setDate(d.getDate()+1);const hm=a.type==="week"?[a.h,a.m]:[new Date(a.at).getHours(),new Date(a.at).getMinutes()];d.setHours(hm[0],hm[1],0,0);ts=d.getTime()}else ts=Date.now()+v*60000;
if(a.type==="date"){R=R.filter(y=>y.id!==a.id);R.push({...a,at:ts})}else{const r=R.find(x=>x.id===a.id);if(r)r.snooze=ts}
AL.shift();sv();render();showAlert()}
function tick(){const n=Date.now();let ch=false;for(const r of [...R]){if(r.type==="date"){if(r.at<=n){fire(r);R=R.filter(x=>x!==r);ch=true}}else if(r.active){if(r.snooze&&r.snooze<=n){fire(r);r.snooze=null;ch=true}if(r.next<=n){fire(r);r.next=nextOcc(r,n);ch=true}}}if(ch){sv();if(tab!=="set")render()}}
document.addEventListener("click",e=>{const el=e.target.closest("[data-tab],[data-a],[data-th],[data-co],[data-lg],[data-sn]");if(!el)return;const D=el.dataset,id=D.id?+D.id:null,r=R.find(x=>x.id===id);
if(D.tab){tab=D.tab;Q="";$("#q").value="";ANIM=true;render()}
else if(D.th){S.theme=D.th;sv();render()}else if(D.co){S.color=D.co;sv();render()}else if(D.lg){S.lang=D.lg;ANIM=true;sv();render()}
else if(D.sn)doSnooze(D.sn);
else switch(D.a){case"new":form(null);break;case"edit":form(id);break;case"close":closeM();break;case"save":saveForm(id,D.w==="1");break;
case"del":modal(`<h3>${t("del")}</h3><p>${t("conf")}</p><div class="acts"><button class="btn sec" data-a="close">${t("cancel")}</button><button class="btn red" data-a="cdel" data-id="${id}">${t("del")}</button></div>`);break;
case"cdel":R=R.filter(x=>x.id!==id);sv();closeM();render();break;
case"pin":r.pin=!r.pin;sv();render();break;
case"tog":r.active=!r.active;r.snooze=null;if(r.active)r.next=nextOcc(r,Date.now());sv();render();break;
case"perm":if(NATIVE)LN.requestPermissions().then(p=>{NP=p.display;render()});else Notification.requestPermission().then(render);break;
case"newt":tForm(null);break;case"rnt":tForm(curT().id);break;
case"savet":{const nm=$("#t_n").value.trim();if(!nm)return;if(id){TB.find(y=>y.id===id).name=nm}else{const n={id:Date.now()+Math.random(),name:nm,items:[]};TB.push(n);selT=n.id}sv();closeM();render();break}
case"selt":selT=id;render();break;
case"delt":confirmM("confT","cdelt",curT().id);break;
case"cdelt":TB=TB.filter(y=>y.id!==id);selT=null;sv();closeM();render();break;
case"adds":sForm(null,+D.d);break;case"eds":sForm(id,0);break;
case"saves":{const sub=$("#s_s").value.trim(),s=$("#s_a").value,e=$("#s_b").value;if(!sub||!s||!e||e<=s)return alert(t("bads"));const T0=curT();let x=T0.items.find(y=>y.id===id);if(!x){x={id:Date.now()+Math.random()};T0.items.push(x)}x.sub=sub;x.s=s;x.e=e;x.day=+$("#s_d").value;sv();closeM();render();break}
case"dels":confirmM("confS","cdels",id);break;
case"cdels":{const T0=curT();T0.items=T0.items.filter(y=>y.id!==id);sv();closeM();render();break}
case"snz":snoozeMenu();break;case"alert":showAlert();break;
case"dis":case"adel":AL.shift();showAlert();break;
case"apause":{const x=R.find(y=>y.id===AL[0].id);if(x){x.active=false;x.snooze=null;sv();render()}AL.shift();showAlert();break}}});
$("#q").addEventListener("input",e=>{Q=e.target.value;renderList()});
function nextNid(){S.nid=(S.nid||0)+1;return S.nid}
let syncT=null,syncing=Promise.resolve();
function queueSync(){if(!NATIVE)return;clearTimeout(syncT);syncT=setTimeout(()=>{syncing=syncing.then(syncAll).catch(()=>{})},300)}
async function syncAll(){
const pend=await LN.getPending();
if(pend.notifications.length)await LN.cancel({notifications:pend.notifications.map(n=>({id:n.id}))});
await LN.createChannel({id:"zk_reminders",name:t("app"),description:t("title"),importance:5,visibility:1,vibration:true});
await LN.registerActionTypes({types:[{id:"DATE",actions:[{id:"snooze",title:t("snooze")},{id:"delete",title:t("del")}]},{id:"WEEK",actions:[{id:"snooze",title:t("snooze")},{id:"pause",title:t("pause")}]}]});
const now=Date.now(),list=[];
for(const r of R){
const b={title:t("title"),body:t("rem")+r.text,channelId:"zk_reminders",actionTypeId:r.type==="week"?"WEEK":"DATE",extra:r};
if(r.type==="date"){if(r.at>now)list.push({...b,id:r.nid*4,schedule:{at:new Date(r.at),allowWhileIdle:true}})}
else if(r.active){list.push({...b,id:r.nid*4,schedule:{on:{weekday:r.day+1,hour:r.h,minute:r.m},allowWhileIdle:true}});
if(r.snooze&&r.snooze>now)list.push({...b,id:r.nid*4+1,schedule:{at:new Date(r.snooze),allowWhileIdle:true}})}}
if(list.length)await LN.schedule({notifications:list})}
function handleAction(ev){
const x=(ev.notification&&ev.notification.extra)||{},a=ev.actionId;if(!x.type)return;
const r=R.find(y=>y.id===x.id);
if(a==="snooze"){const rec=r||(x.type==="date"?{...x}:null);if(!rec)return;AL.unshift({...rec});snoozeMenu()}
else if(a==="delete"){R=R.filter(y=>y.id!==x.id);sv();render()}
else if(a==="pause"&&r){r.active=false;r.snooze=null;sv();render()}}
async function nativeInit(){
try{let p=await LN.checkPermissions();if(p.display==="prompt"||p.display==="prompt-with-rationale")p=await LN.requestPermissions();NP=p.display}catch(e){}
try{const e=await LN.checkExactNotificationSetting();if(e.exact_alarm==="denied")await LN.changeExactNotificationSetting()}catch(e){}
try{await LN.addListener("localNotificationActionPerformed",handleAction)}catch(e){}
queueSync();if(tab==="set")render()}
R.forEach(r=>{if(!r.nid)r.nid=nextNid()});sv();
render();tick();setInterval(tick,10000);document.addEventListener("visibilitychange",()=>{tick();if(!document.hidden)queueSync()});window.addEventListener("focus",queueSync);if(NATIVE)nativeInit();
